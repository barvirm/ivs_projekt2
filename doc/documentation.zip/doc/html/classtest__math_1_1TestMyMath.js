var classtest__math_1_1TestMyMath =
[
    [ "test_cos", "classtest__math_1_1TestMyMath.html#a6db30bf611f9c79dcf9bc90fbbf3151f", null ],
    [ "test_factorial", "classtest__math_1_1TestMyMath.html#a05f1848be37bd6de5c344cb3c956b2c9", null ],
    [ "test_ln", "classtest__math_1_1TestMyMath.html#ab10976331cb6169a74d5f06f1e20aac5", null ],
    [ "test_modulo", "classtest__math_1_1TestMyMath.html#a3aac2480b3861a098663bad1b298d14a", null ],
    [ "test_pow", "classtest__math_1_1TestMyMath.html#a2ca25084e7704f6307f7dd73f23eb2fd", null ],
    [ "test_sin", "classtest__math_1_1TestMyMath.html#ae367441d525ec96885a60e14773e64e3", null ],
    [ "test_sqrt", "classtest__math_1_1TestMyMath.html#a7861e6be02fc3a9d485f2b0b890431d7", null ],
    [ "test_tan", "classtest__math_1_1TestMyMath.html#a539e3dfb9c819d6b53c24cd00a006087", null ]
];