var searchData=
[
  ['factorial',['factorial',['../namespacemy__math.html#a6c3193149960da6571481b7cb24ff3d9',1,'my_math']]]
];
