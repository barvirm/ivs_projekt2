var searchData=
[
  ['about',['about',['../classmain_1_1Calculator.html#a5a01e09091c4b830092db970d7523d81',1,'main::Calculator']]],
  ['app',['app',['../namespacemain.html#a175d512ad2783238ce93f1bc903c0cf4',1,'main']]]
];
