var searchData=
[
  ['digits',['digits',['../namespacemy__math.html#a1841a6720706e0f3b8be8d026a000bc6',1,'my_math']]]
];
