var searchData=
[
  ['get_5fradio_5fstate',['get_radio_state',['../classmain_1_1Calculator.html#a640d2a903a1a6a231c6e807006601950',1,'main::Calculator']]],
  ['gridlines',['gridlines',['../classmain_1_1Calculator.html#a5ea2e11c8c644fce7c8b86106c7d722b',1,'main::Calculator']]],
  ['gui_5finit',['gui_init',['../classmain_1_1Calculator.html#a0e55a23b4d6717e73f8b8bd878fe9452',1,'main::Calculator']]]
];
