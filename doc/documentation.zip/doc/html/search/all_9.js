var searchData=
[
  ['ln',['ln',['../namespacemy__math.html#a17cb920edbd7d2300770a4c1b36ba101',1,'my_math']]]
];
