var searchData=
[
  ['window',['window',['../classmain_1_1Calculator.html#a825a7def33881d46c00b0c15b35caa67',1,'main::Calculator']]]
];
