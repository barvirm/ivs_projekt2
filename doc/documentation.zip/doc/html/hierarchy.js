var hierarchy =
[
    [ "main.Calculator", "classmain_1_1Calculator.html", null ],
    [ "Testing", "classTesting.html", null ],
    [ "TestCase", null, [
      [ "test_math.TestMyMath", "classtest__math_1_1TestMyMath.html", null ],
      [ "test_string.TestTransformString", "classtest__string_1_1TestTransformString.html", null ]
    ] ]
];