var namespaces =
[
    [ "main", "namespacemain.html", null ],
    [ "my_math", "namespacemy__math.html", null ],
    [ "test_math", "namespacetest__math.html", null ],
    [ "test_string", "namespacetest__string.html", null ],
    [ "transform_string", "namespacetransform__string.html", null ]
];