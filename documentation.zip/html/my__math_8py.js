var my__math_8py =
[
    [ "cos", "my__math_8py.html#a3164511f86af2be4d02fc4be0d0c31d8", null ],
    [ "cotg", "my__math_8py.html#ac369802e29671e5f7bd3a1abfc7d7d20", null ],
    [ "factorial", "my__math_8py.html#a6c3193149960da6571481b7cb24ff3d9", null ],
    [ "ln", "my__math_8py.html#a17cb920edbd7d2300770a4c1b36ba101", null ],
    [ "modulo", "my__math_8py.html#a5a5b04f873beeb56fed23f42bb1b5423", null ],
    [ "pow", "my__math_8py.html#af0241da41067f587799aa70ee6fd4dbc", null ],
    [ "sin", "my__math_8py.html#a60595834565d64bf955029a9cefdd8d4", null ],
    [ "sqrt", "my__math_8py.html#aa4f454b8a6c77bcd2828ff09919623ad", null ],
    [ "tg", "my__math_8py.html#a9586aed4f9371618e127cdbcc4fa2bd8", null ],
    [ "digits", "my__math_8py.html#a1841a6720706e0f3b8be8d026a000bc6", null ],
    [ "e", "my__math_8py.html#a7e5013f24e6d29cd499e5c322eaf5d24", null ],
    [ "pi", "my__math_8py.html#a71db7877037106550d8e9940748e6741", null ]
];