var namespacetest__math =
[
    [ "TestMyMath", "classtest__math_1_1TestMyMath.html", "classtest__math_1_1TestMyMath" ]
];