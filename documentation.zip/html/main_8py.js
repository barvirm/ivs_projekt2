var main_8py =
[
    [ "Calculator", "classmain_1_1Calculator.html", "classmain_1_1Calculator" ],
    [ "app", "main_8py.html#a175d512ad2783238ce93f1bc903c0cf4", null ]
];