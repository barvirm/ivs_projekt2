var namespacetest__string =
[
    [ "TestTransformString", "classtest__string_1_1TestTransformString.html", "classtest__string_1_1TestTransformString" ]
];