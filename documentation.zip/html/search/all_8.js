var searchData=
[
  ['help',['help',['../classmain_1_1Calculator.html#a0149dc96d5c847cc27ec4fef7235831c',1,'main::Calculator']]],
  ['history',['history',['../classmain_1_1Calculator.html#aff03dd055c46c579327f6e25c3ed26ff',1,'main::Calculator']]],
  ['history_5fadd',['history_add',['../classmain_1_1Calculator.html#a2f7f29fac3359ff28ca9e8662f67a766',1,'main::Calculator']]],
  ['history_5fchange',['history_change',['../classmain_1_1Calculator.html#afdb31f521ce5705abae6f181c75b3b81',1,'main::Calculator']]],
  ['history_5fpages',['history_pages',['../classmain_1_1Calculator.html#a943a43742a71c96a5b53101013a401a7',1,'main::Calculator']]]
];
