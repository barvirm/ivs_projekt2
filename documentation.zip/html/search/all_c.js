var searchData=
[
  ['on_5fmain_5fwindow_5fdestroy',['on_main_window_destroy',['../classmain_1_1Calculator.html#a078448eac97c0a1005c5ddffd5d9f297',1,'main::Calculator']]]
];
