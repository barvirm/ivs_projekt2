var searchData=
[
  ['help',['help',['../classmain_1_1Calculator.html#a0149dc96d5c847cc27ec4fef7235831c',1,'main::Calculator']]],
  ['history_5fadd',['history_add',['../classmain_1_1Calculator.html#a2f7f29fac3359ff28ca9e8662f67a766',1,'main::Calculator']]],
  ['history_5fchange',['history_change',['../classmain_1_1Calculator.html#afdb31f521ce5705abae6f181c75b3b81',1,'main::Calculator']]]
];
