var searchData=
[
  ['test_5fmath',['test_math',['../namespacetest__math.html',1,'']]],
  ['test_5fstring',['test_string',['../namespacetest__string.html',1,'']]],
  ['transform_5fstring',['transform_string',['../namespacetransform__string.html',1,'']]]
];
