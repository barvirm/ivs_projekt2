var searchData=
[
  ['gridlines',['gridlines',['../classmain_1_1Calculator.html#a5ea2e11c8c644fce7c8b86106c7d722b',1,'main::Calculator']]]
];
