var files =
[
    [ "main.py", "main_8py.html", "main_8py" ],
    [ "my_math.py", "my__math_8py.html", "my__math_8py" ],
    [ "test_math.py", "test__math_8py.html", [
      [ "TestMyMath", "classtest__math_1_1TestMyMath.html", "classtest__math_1_1TestMyMath" ]
    ] ],
    [ "test_string.py", "test__string_8py.html", [
      [ "TestTransformString", "classtest__string_1_1TestTransformString.html", "classtest__string_1_1TestTransformString" ]
    ] ],
    [ "transform_string.py", "transform__string_8py.html", "transform__string_8py" ]
];